#!/bin/sh

cat > /dev/null
